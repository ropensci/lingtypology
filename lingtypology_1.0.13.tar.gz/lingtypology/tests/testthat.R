library(testthat)
library(lingtypology)

test_check("lingtypology")
